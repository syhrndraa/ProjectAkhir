
package model;

import DBConnect.DBConnect;
import controller.LokasiController;
import java.sql.*;
import javax.swing.JOptionPane;

public class LokasiModel  {
    private Connection connection;
    private Statement statement;

    public LokasiModel(){
        DBConnect dbConnect = new DBConnect();
        connection = dbConnect.getConnection();
    }
    
    public void createLokasi(String [] data){
        try{
            String query = "INSERT INTO `lokasi`(`nama_lokasi`, `kota`, `vaksin1`, `vaksin2`) VALUES ('"+data[0]+"','"+data[1]+"','"+data[2]+"','"+data[3]+"')";
            statement = connection.createStatement();
            statement.executeUpdate(query);
            connection.close();
            JOptionPane.showMessageDialog(null, "Input Successfull");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    
    }

    
    public int countData(){ 
        int jmlData = 0; 
        try{
            statement = connection.createStatement();
            String query = "Select * from `lokasi`";
            ResultSet resultSet = statement.executeQuery(query); 
            while(resultSet.next()){ 
                jmlData++;
            }
            return jmlData;
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            System.out.println("SQL Error");
            return 0;
        }    
    }
    
    public String [][] readDataLokasi(){
       try{
            int jmlData = 0; 
            String data[][] = new String[countData()][5];
            String query = "Select * from `lokasi`"; 
            ResultSet resultSet = statement.executeQuery(query); 
            while(resultSet.next()){
                data[jmlData][0] = resultSet.getString("id");
                data[jmlData][1] = resultSet.getString("nama_lokasi");
                data[jmlData][2] = resultSet.getString("kota"); 
                data[jmlData][3] = resultSet.getString("vaksin1"); 
                data[jmlData][4] = resultSet.getString("vaksin2");
                jmlData++; 
                
            }
            return data;
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            System.out.println("SQL Error");
            return null;
        }
    }
    
    public String[] readDataLokasi(String id){
    try{     
            String[] data = new String[5];
            statement = connection.createStatement();
            String query = "select * from lokasi where id = '"+id+"' "; 
            ResultSet resultSet = statement.executeQuery(query); 
            while(resultSet.next()){
                data[0] = resultSet.getString("id");
                data[1] = resultSet.getString("nama_lokasi");
                data[2] = resultSet.getString("kota"); 
                data[3] = resultSet.getString("vaksin1"); 
                data[4] = resultSet.getString("vaksin2");
             
            }
            return data;
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            System.out.println("SQL Error oik");
            return null;
        }
    }
    
    public void updateLokasi(String[] data){
     try{
            String query = "UPDATE `lokasi` set `nama_lokasi` = '"+data[1]+"', `kota` = '"+data[2]+"', `vaksin1` = '"+data[3]+"', `vaksin2` = '"+data[4]+"' where `id` = '"+data[0]+"'";
            statement = connection.createStatement();
            statement.executeUpdate(query);
            LokasiController lokasi = new LokasiController();
            lokasi.readDataLokasi();
            System.out.println("Update Successful!");
            JOptionPane.showMessageDialog(null,"Update Successful!");
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public void deleteLokasi(String id){
     try{
            String query = "DELETE FROM `lokasi` WHERE `id` = '"+id+"'";
            statement = connection.createStatement();
            statement.executeUpdate(query);            
            LokasiController lokasi = new LokasiController();
            lokasi.readDataLokasi();
            System.out.println("Delete Successful!");
            JOptionPane.showMessageDialog(null,"Delete Successful!");
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    

}
