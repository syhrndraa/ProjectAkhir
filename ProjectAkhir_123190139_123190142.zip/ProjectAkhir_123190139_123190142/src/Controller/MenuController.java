
package controller;

import view.MenuView;

public class MenuController {
    public void openMenu(){
        new MenuView();
    }
}
