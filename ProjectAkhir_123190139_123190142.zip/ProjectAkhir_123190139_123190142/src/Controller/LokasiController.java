
package controller;

import model.LokasiModel;
import view.*;

public class LokasiController {
    
    public void createLokasi(){
        LokasiInputView input = new LokasiInputView();
        input.openForm();
    }
    
    public void createLokasi(String [] data){
        LokasiModel model = new LokasiModel();
        model.createLokasi(data);
    }
    
    public void readDataLokasi(){
        
        LokasiModel model = new LokasiModel();
        String[][] data = model.readDataLokasi();
        if(data == null)
            new MenuView();
        else
           new LokasiView(data);
    }
    
    public void readDataLokasi(String id){
        LokasiModel model = new LokasiModel();
        DetailLokasiView detail = new DetailLokasiView();
        detail.openDetail(model.readDataLokasi(id));
    }
    
    public void updatePanel(String[] data){
        LokasiUpdateView view = new LokasiUpdateView();
        view.openForm(data);
    }
    public void updateLokasi(String[] data){
        LokasiModel model = new LokasiModel();
        model.updateLokasi(data);
    }
    
    public void deleteLokasi(String id){
        LokasiModel model = new LokasiModel();
        model.deleteLokasi(id);
    
    }
    
}
