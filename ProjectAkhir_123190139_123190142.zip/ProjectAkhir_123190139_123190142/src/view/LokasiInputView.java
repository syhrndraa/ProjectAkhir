
package view;

import controller.LokasiController;
import controller.MenuController;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class LokasiInputView extends JFrame implements ActionListener{
    
    private JLabel lmain, lnama_lokasi, lvaksin1, lvaksin2, ldaerah;
    private JTextField nama_lokasi, vaksin1, vaksin2;
    private JButton btnSubmit, btnReset, btnBack;
    private JComboBox cmbDaerah;
    
    public void openForm(){
    
        setLayout(null);
        setSize(480,310);
        setVisible(true);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("INPUT DATA");
        lmain = new JLabel("Input Lokasi Layanan Vaksinasi");
        lnama_lokasi = new JLabel("Nama Lokasi");
        lvaksin1 = new JLabel("Jumlah Orang Vaksin ke-1 ");
        lvaksin2 = new JLabel("Jumlah Orang Vaksin ke-2 ");
        ldaerah = new JLabel("Kota/Kabupaten dari Lokasi");
    
        nama_lokasi = new JTextField();
        vaksin1 = new JTextField();
        vaksin2 = new JTextField();
    
        btnSubmit = new JButton("Submit");
        btnReset = new JButton("Reset");
        btnBack = new JButton("🢀 Back");
        
        cmbDaerah = new JComboBox();
        cmbDaerah.addItem("");
        cmbDaerah.addItem("Yogyakarta");
        cmbDaerah.addItem("Sleman");
        cmbDaerah.addItem("Kulon Progo");
        cmbDaerah.addItem("Bantul");
        cmbDaerah.addItem("Gunung Kidul");
        
        add(lmain);
        add(lnama_lokasi);
        add(lvaksin1);
        add(lvaksin2);
        add(nama_lokasi);
        add(vaksin1);
        add(vaksin2);
        add(btnSubmit);
        add(btnReset);
        add(btnBack);
        add(cmbDaerah);
        add(ldaerah);
        
        lmain.setBounds(150, 10, 190, 25);
        lnama_lokasi.setBounds(20, 70, 145, 25);
        nama_lokasi.setBounds(250, 70, 190, 25);
        lvaksin1.setBounds(20, 130, 180, 25);
        vaksin1.setBounds(250, 130, 190, 25);
        lvaksin2.setBounds(20, 160, 180, 25);
        vaksin2.setBounds(250, 160, 190, 25);
        btnSubmit.setBounds(340, 195, 100, 25);
        btnReset.setBounds(340, 230, 100, 25);
        btnBack.setBounds(10, 230, 80, 25);
        cmbDaerah.setBounds(250, 100, 190, 25);
        ldaerah.setBounds(20, 100, 180, 25);
        
        btnSubmit.setBackground(Color.green);
        btnReset.setBackground(Color.red);
        btnSubmit.setForeground(Color.white);
        btnReset.setForeground(Color.white);
        
        cmbDaerah.addActionListener(this);
        btnSubmit.addActionListener(this);
        btnReset.addActionListener(this);
        btnBack.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== btnSubmit){
            
            if (nama_lokasi.getText().equals("")) {
                setMessage("Nama lokasi belum diisi!");
            }
            if(cmbDaerah.getSelectedItem().equals("")){
                setMessage("Kabupaten/Kota belum diisi");
            }
            if (vaksin1.getText().equals("")) {
                setMessage("Jumlah vaksin 1 belum diisi!");
            }
            if (vaksin2.getText().equals("")) {
                setMessage("Jumlah vaksin 2  belum diisi!");
            } 
            else if(vaksin1.getText().matches("^[a-zA-Z]*$") || vaksin2.getText().matches("^[a-zA-Z]*$")){
                     setMessage("Vaksin 1 dan vaksin 2 harus berupa bilangan");
            }
            else {
                
                if(Float.valueOf(vaksin1.getText()) < 0 || Float.valueOf(vaksin2.getText()) < 0){
                    setMessage("Harus berupa bilangan positif");
                }else{
                    String[] data = {
                        nama_lokasi.getText(), cmbDaerah.getSelectedItem().toString(), vaksin1.getText(), vaksin2.getText()
                    };
                    LokasiController lokasi = new LokasiController();
                    lokasi.createLokasi(data);
                    new MenuView();
                    dispose();
                }
            }
        }
        else if(e.getSource()== btnReset){
            nama_lokasi.setText("");
            cmbDaerah.setSelectedItem("");
            vaksin1.setText("");
            vaksin2.setText("");
        }
        else if(e.getSource() == btnBack){
            dispose();
            MenuController menu = new MenuController();
            menu.openMenu();
        }
    }
    
    public void setMessage(String message){
     JOptionPane.showMessageDialog(this, message);
    }
    
}
