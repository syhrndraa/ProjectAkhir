/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.LokasiController;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
/**
 *
 * @author ASUS
 */
public class DetailLokasiView extends JFrame implements ActionListener{

    private JLabel lnama_lokasi, lvaksin1, lvaksin2, ldaerah, nama_lokasi, daerah, vaksin1, vaksin2;
    private JButton btnBack, btnEdit, btnDelete;
    private String id;
    private String[] dataa;
        
    public void openDetail(String[] data){
        
        this.id = data[0];
        this.dataa = data;
        
        setLayout(null);
        setSize(450,230);
        setVisible(true);
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle(data[1]);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        lnama_lokasi = new JLabel("Nama Lokasi                              : ");
        ldaerah = new JLabel("Kota/Kabupaten dari Lokasi   :");
        lvaksin1 = new JLabel("Jumlah Orang Vaksin ke-1     :");
        lvaksin2 = new JLabel("Jumlah Orang Vaksin ke-2     :");
        nama_lokasi = new JLabel(data[1]);
        daerah = new JLabel(data[2]);
        vaksin1 = new JLabel(data[3]);
        vaksin2 = new JLabel(data[4]);
        
        btnBack = new JButton("🢀 Back");
        btnEdit = new JButton("Edit");
        btnDelete = new JButton("Delete");
        
        add(lnama_lokasi);
        add(ldaerah);
        add(lvaksin1);
        add(lvaksin2);
        add(nama_lokasi);
        add(daerah);
        add(vaksin1);
        add(vaksin2);
        add(btnBack);
        add(btnEdit);
        add(btnDelete);
        
        
        lnama_lokasi.setBounds(20, 10, 180, 25);
        nama_lokasi.setBounds(200, 10, 250, 25);
        ldaerah.setBounds(20, 35, 180, 25);
        daerah.setBounds(200, 35, 180, 25);
        lvaksin1.setBounds(20, 60, 170, 25);
        vaksin1.setBounds(200, 60, 130, 25);
        lvaksin2.setBounds(20, 85, 170, 25);
        vaksin2.setBounds(200, 85, 130, 25);
        btnBack.setBounds(10, 150, 80, 25);
        btnEdit.setBounds(320, 120, 100, 25);
        btnDelete.setBounds(320, 150, 100, 25);
        
        btnEdit.setBackground(Color.blue);
        btnDelete.setBackground(Color.red);
        btnEdit.setForeground(Color.white);
        btnDelete.setForeground(Color.white);
        
        
        btnEdit.addActionListener(this);
        btnDelete.addActionListener(this);
        btnBack.addActionListener(this);
     
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== btnEdit){
                dispose();
                 LokasiController lokasi = new LokasiController();
                 lokasi.updatePanel(dataa);
        }
        else if(e.getSource() == btnDelete){
            
        int opsi = JOptionPane.showConfirmDialog(null, "Benarkah anda ingin menghapus data ini ?");
        switch(opsi){
            case JOptionPane.YES_OPTION:
                 dispose();
                 LokasiController lokasi = new LokasiController();
                 lokasi.deleteLokasi(id);
                break;
            case JOptionPane.NO_OPTION:
                break;
            default:
                break;
        }    
        }
        else if(e.getSource() == btnBack){
            dispose();
            LokasiController lokasi = new LokasiController();
            lokasi.readDataLokasi();
        }
    }

    private void setMessage(String message) {
      JOptionPane.showMessageDialog(this, message);
    }
}
