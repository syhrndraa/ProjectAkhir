
package view;

import controller.LokasiController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MenuView extends JFrame implements ActionListener{
    
    private JLabel labmain;
    private JButton btnAdd, btnShow;
    
    public MenuView(){
    
        setLayout(null);
        setSize(290,160);
        setVisible(true);
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("MAIN MENU");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        labmain = new JLabel("Pendataan Lokasi Vaksinasi DIY");
        btnAdd = new JButton("Tambah Data");
        btnShow = new JButton("Lihat Data");
        
        add(labmain);
        add(btnAdd);
        add(btnShow);
        
        labmain.setBounds(45, 10, 200, 25);
        btnAdd.setBounds(65, 45, 150, 25);
        btnShow.setBounds(65, 75, 150, 25);
        
        btnAdd.addActionListener(this);
        btnShow.addActionListener(this);
      
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== btnAdd){
            LokasiController lokasi = new LokasiController();
            lokasi.createLokasi();
            dispose();
        }
        else if(e.getSource()== btnShow){
            LokasiController lokasi = new LokasiController();
            lokasi.readDataLokasi();
            dispose();
        }
       
    }
    
}
