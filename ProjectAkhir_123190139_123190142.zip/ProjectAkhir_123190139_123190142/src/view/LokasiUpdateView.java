package view;

import controller.LokasiController;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class LokasiUpdateView  extends JFrame implements ActionListener {
    
    private JLabel lmain, lnama_lokasi, lvaksin1, lvaksin2, ldaerah;
    private JTextField nama_lokasi, vaksin1, vaksin2;
    private JButton btnUpdate, btnReset, btnBack;
    private String id;
    private JComboBox cmbDaerah;
    
    public void openForm(String[] data){
       
        this.id = data[0];
        
        setLayout(null);
        setSize(480,310);
        setVisible(true);
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle(data[1]);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        lmain = new JLabel("Update Lokasi Vaksinasi");
        lnama_lokasi = new JLabel("Nama Lokasi");
        ldaerah = new JLabel("Kota/Kabupaten dari Lokasi");
        lvaksin1 = new JLabel("Jumlah Orang Vaksin ke-1");
        lvaksin2 = new JLabel("Jumlah Orang Vaksin ke-2");
    
        nama_lokasi = new JTextField(data[1]);
        cmbDaerah = new JComboBox();
        cmbDaerah.addItem("");
        cmbDaerah.addItem("Yogyakarta");
        cmbDaerah.addItem("Sleman");
        cmbDaerah.addItem("Kulon Progo");
        cmbDaerah.addItem("Bantul");
        cmbDaerah.addItem("Gunung Kidul");
        cmbDaerah.setSelectedItem(data[2]);
        vaksin1 = new JTextField(data[3]);
        vaksin2 = new JTextField(data[4]);
    
        btnUpdate = new JButton("Update");
        btnReset = new JButton("Reset");
        btnBack = new JButton("🢀 Back");
        
        add(lmain);
        add(lnama_lokasi);
        add(lvaksin1);
        add(lvaksin2);
        add(nama_lokasi);
        add(vaksin1);
        add(vaksin2);
        add(btnUpdate);
        add(btnReset);
        add(btnBack);
        add(cmbDaerah);
        add(ldaerah);
        
        lmain.setBounds(150, 10, 190, 25);
        lnama_lokasi.setBounds(20, 70, 145, 25);
        nama_lokasi.setBounds(250, 70, 190, 25);
        lvaksin1.setBounds(20, 130, 180, 25);
        vaksin1.setBounds(250, 130, 190, 25);
        lvaksin2.setBounds(20, 160, 180, 25);
        vaksin2.setBounds(250, 160, 190, 25);
        btnUpdate.setBounds(340, 195, 100, 25);
        btnReset.setBounds(340, 230, 100, 25);
        btnBack.setBounds(10, 230, 80, 25);
        cmbDaerah.setBounds(250, 100, 190, 25);
        ldaerah.setBounds(20, 100, 180, 25);
        
        btnUpdate.setBackground(Color.blue);
        btnReset.setBackground(Color.red);
        btnUpdate.setForeground(Color.white);
        btnReset.setForeground(Color.white);
        
        btnUpdate.addActionListener(this);
        btnReset.addActionListener(this);
        btnBack.addActionListener(this);
        cmbDaerah.addActionListener(this);
    
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== btnUpdate){
            if (nama_lokasi.getText().equals("")) {
                setMessage("Nama lokasi belum diisi!");
            }
            if(cmbDaerah.getSelectedItem().equals("")){
                setMessage("Kabupaten/Kota belum diisi");
            }
            if (vaksin1.getText().equals("")) {
                setMessage("Jumlah vaksin 1 belum diisi!");
            }
            if (vaksin2.getText().equals("")) {
                setMessage("Jumlah vaksin 2 belum diisi!");
            }
            if(vaksin1.getText().matches("^[a-zA-Z]*$") || vaksin2.getText().matches("^[a-zA-Z]*$")){
                     setMessage("Vaksin 1 dan vaksin 2 harus berupa bilangan");
            }
            else {
                if(Float.valueOf(vaksin1.getText()) < 0 || Float.valueOf(vaksin2.getText()) <0){
                     setMessage("Harus berupa bilangan positif");
                }
                else{
                String[] data = {
                   id, nama_lokasi.getText(), cmbDaerah.getSelectedItem().toString(), vaksin1.getText(), vaksin2.getText()
                };
                LokasiController lokasi = new LokasiController();
                lokasi.updateLokasi(data);
                dispose();
                }
            }
        }
        else if(e.getSource()== btnReset){
            nama_lokasi.setText("");
            cmbDaerah.setSelectedItem("");
            vaksin1.setText("");
            vaksin2.setText("");
        }
        else if(e.getSource() == btnBack){
            dispose();
            LokasiController lokasi = new LokasiController();
            lokasi.readDataLokasi(id);
        }
    }

    private void setMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
    
}
